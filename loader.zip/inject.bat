@echo off
setlocal enabledelayedexpansion

set ADB=adb
set INJ=injector
set SO=libinternal.so
set PKG=com.standrise.game
set MAXTRY=3
set DEV_SO=/data/user/0/com.standrise.game/files/libinternal.so

rem ---------- find adb ----------
if exist "%~dp0adb.exe" set ADB=%~dp0adb.exe
if exist "C:\platform-tools\adb.exe" set ADB=C:\platform-tools\adb.exe

echo.
echo ============================================
echo Standrise internal injector
echo ============================================
echo.
echo [*] adb: %ADB%

if not exist "%ADB%" (
    echo [!] adb not found: %ADB%
    goto end
)

rem ---------- connect to emulator ----------
echo [*] connecting to 127.0.0.1:5555...
%ADB% connect 127.0.0.1:5555 >nul 2>&1
ping -n 3 127.0.0.1 >nul

rem ---------- get device serial ----------
set DEVICE=
for /f "tokens=1" %%a in ('%ADB% devices ^| findstr /R /C:"device" ^| findstr /V /C:"List"') do (
    if not defined DEVICE set DEVICE=%%a
)

if not defined DEVICE (
    echo [!] no device found
    echo [*] run: %ADB% devices
    goto end
)

echo [*] device: %DEVICE%

if not exist "%INJ%" (
    echo [!] injector not found: %INJ%
    goto end
)

if not exist "%SO%" (
    echo [!] libinternal.so not found
    goto end
)

rem ---------- find su FIRST ----------
set SU_CMD=su
%ADB% -s %DEVICE% shell "/boot/android/dataFS/downloads/.xb/su -c 'id'" >nul 2>&1
if errorlevel 1 (
    echo [*] using plain su
) else (
    set SU_CMD=/boot/android/dataFS/downloads/.xb/su
    echo [*] using custom su: /boot/android/dataFS/downloads/.xb/su
)

rem ---------- push libinternal.so to /data/local/tmp ----------
echo [*] pushing libinternal.so to /data/local/tmp...
%ADB% -s %DEVICE% push "%SO%" /data/local/tmp/libinternal.so >nul

rem ---------- copy to app files via su ----------
echo [*] copying to app files via !SU_CMD!...
%ADB% -s %DEVICE% shell "!SU_CMD! -c 'mkdir -p /data/user/0/com.standrise.game/files && cp /data/local/tmp/libinternal.so !DEV_SO! && chmod 644 !DEV_SO! && chown $(stat -c %%u:%%g /data/user/0/com.standrise.game/files) !DEV_SO! 2>/dev/null; restorecon !DEV_SO! 2>/dev/null; ls -laZ !DEV_SO!'"

rem ---------- verify file exists ----------
echo [*] verifying file...
%ADB% -s %DEVICE% shell "!SU_CMD! -c 'ls -la !DEV_SO! 2>&1'"

rem ---------- push injector ----------
echo [*] pushing injector...
%ADB% -s %DEVICE% push "%INJ%" /data/local/tmp/injector >nul
%ADB% -s %DEVICE% shell "!SU_CMD! -c 'chmod 755 /data/local/tmp/injector'"

set /a TRY=0
:retry
set /a TRY+=1
echo.
echo [*] attempt !TRY! of %MAXTRY%

echo [*] stopping game...
%ADB% -s %DEVICE% shell "am force-stop %PKG%" >nul 2>&1
%ADB% -s %DEVICE% logcat -c >nul 2>&1

echo [*] running injector...
%ADB% -s %DEVICE% shell "!SU_CMD! -c '/data/local/tmp/injector 2>&1'"

echo [*] waiting for game...
ping -n 10 127.0.0.1 >nul

set GAMEPID=
%ADB% -s %DEVICE% shell pidof %PKG% > "%TEMP%\sr_pid.txt" 2>nul
set /p GAMEPID=<%TEMP%\sr_pid.txt
set GAMEPID=%GAMEPID: =%

if not "!GAMEPID!"=="" (
    echo [*] game alive, pid=!GAMEPID!
    goto logs
)

echo [!] game did not start

if !TRY! lss %MAXTRY% (
    echo [*] retrying...
    goto retry
)

echo [!] attempts exhausted

:logs
echo.
echo ===== internal log =====
%ADB% -s %DEVICE% logcat -d -s internal:V

:end
echo.
pause
endlocal
